<header class="header">
    <div>
        <img class="logo1" src="Img/tlaco.jpeg" alt="logo">
    </div>
    <div style="font-size: 25px; width: 50%; padding-top: 45px; text-align: center">
        <div>
            <h3>H. AYUNTAMIENTO DE TLACOTEPEC DE BENITO JUARÉZ PUE</h3>
            <h3 style="padding-top: 50px; color: purple">LICENCIA DE FUNCIONAMIENTO</h3>
        </div>
    </div>
    <div>
        <img class="logo2" style="padding-left: 25px" src="Img/2doLogo.jpeg" alt="logo">
    </div>
</header>