@extends('layout')


@section('content')

@include('funcionamiento')
@include('cancelacion')
@endsection








