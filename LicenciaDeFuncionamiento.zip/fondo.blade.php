<img class="costado" src="Img/margenIzq.jpg" alt="">
<img class="pie" src="Img/pie.jpg" alt="pie de pagina">
<div class="fondo">
    <img class="backimg" src="Img/escudo.jpg" alt="">
</div>
<img class="qr" src="Img/Qr.png" alt="">